namespace TragamonedasApp.Models
{
    public class Maquina
    {
        public string Codigo { get; set; }
        public string Ubicacion { get; set; }
        public string Estado { get; set; }
    }
}